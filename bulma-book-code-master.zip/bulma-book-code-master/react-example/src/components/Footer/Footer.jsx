import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <footer className="footer">
        <p className="has-text-centered">Copyright &copy; 2018. All Rights Reserved</p>
      </footer>
    );
  }
}

export default Footer;
