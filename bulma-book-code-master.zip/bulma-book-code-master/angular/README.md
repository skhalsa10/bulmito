# Angular seed
The seed for Angular apps
