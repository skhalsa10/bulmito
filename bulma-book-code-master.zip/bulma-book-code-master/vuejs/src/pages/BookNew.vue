<<template>
  
</template>

<script>
export default {
  name: "BookNew"

}
</script>

<style>

</style>
