<<template>
  
</template>

<script>
export default {
  name: "CustomerNew"

}
</script>

<style>

</style>
